/*----------------Caps Lock Detection--------------------------------*/
function closeCapsLock(id){
	document.getElementById(id).style.display = "none";
	document.logon.password.focus();
	if (document.noPopup.popCheck.checked == true){
		showPopupOnce();
	}
}
function contPasswd(id){
	document.getElementById(id).style.display = "none";
	document.logon.password.focus();
	hidePopupSession();
}
function passReEnter(id){
	document.getElementById(id).style.display = "none";
	document.logon.password.value = "";
	document.logon.password.focus();
}
function submitform()
{
  document.logon.submit();
}

function mySetCookie(c_name,value,expiredays,secure){
var exdate = new Date();
exdate.setDate(exdate.getDate()+expiredays);
document.cookie=c_name+ "=" +escape(value)+((expiredays==null) ? "" : ";expires="+exdate.toGMTString());
document.cookie += "secure; ";
}

function myGetCookie(c_name)
{
if (document.cookie.length>0)
  {
  c_start=document.cookie.indexOf(c_name + "=")
  if (c_start!=-1)
    {
    c_start=c_start + c_name.length+1
    c_end=document.cookie.indexOf(";",c_start)
    if (c_end==-1) c_end=document.cookie.length
    return unescape(document.cookie.substring(c_start,c_end))
    }
  }
return ""
}
function showPopupOnce() {
   mySetCookie("has_seen_popup", "true", 365, true); // 365 days = 1 year
}
function hidePopupSession() {
   mySetCookie("hide_this_session", "true", 1, true); // 1 days
}

/*------------------------Caps Lock Detection Script--------------------------------*/
var capslock = {
  init: function() {
    if (!document.getElementsByTagName) {
      return;
    }
    // Find all password fields in the page, and set a keypress event on them
    var inps = document.getElementsByTagName("input");
    for (var i=0, l=inps.length; i<l; i++) {
      if (inps[i].type == "password") {
        capslock.addEvent(inps[i], "keypress", capslock.keypress);
      }
    }
  },
  addEvent: function(obj,evt,fn) {
    if (document.addEventListener) {
      capslock.addEvent = function (obj,evt,fn) {
        obj.addEventListener(evt,fn,false);
      };
      capslock.addEvent(obj,evt,fn);
    } else if (document.attachEvent) {
      capslock.addEvent = function (obj,evt,fn) {
        obj.attachEvent('on'+evt,fn);
      };
      capslock.addEvent(obj,evt,fn);
    } else {
      // no support for addEventListener *or* attachEvent, so quietly exit
    }
  },
  keypress: function(e) {
    var ev = e ? e : window.event;
    if (!ev) {
      return;
    }
    var targ = ev.target ? ev.target : ev.srcElement;
    // get key pressed
    var which = -1;
    if (ev.which) {
      which = ev.which;
    } else if (ev.keyCode) {
      which = ev.keyCode;
    }
    // get shift status
    var shift_status = false;
    if (ev.shiftKey) {
      shift_status = ev.shiftKey;
    } else if (ev.modifiers) {
      shift_status = !!(ev.modifiers & 4);
    }
    if (((which >= 65 && which <=  90) && !shift_status) ||
        ((which >= 97 && which <= 122) && shift_status)) {
      // uppercase, no shift key
			var hasSeenPopup = myGetCookie("has_seen_popup");
			var hideThisSession = myGetCookie("hide_this_session");
  		//if (hasSeenPopup == "" || hideThisSession == ""){
			if (hasSeenPopup == null || hasSeenPopup == ""){
				if (hideThisSession == null || hideThisSession == ""){
					capslock.show_warning(targ);
				}
			}
    } else {
      capslock.hide_warning(targ);
    }
  },
  
  show_warning: function(targ) {
    if (!targ.warning) {
			document.noPopup.popCheck.checked = false;
      document.getElementById("capsLokMsg").style.display = "block";
			return false;
    }
  },
  hide_warning: function(targ) {
    if (targ.warning) {
      targ.warning.parentNode.removeChild(targ.warning);
      targ.warning = null;
    }
  }
};

(function(i) {var u =navigator.userAgent;var e=/*@cc_on!@*/false; var st =
setTimeout;if(/webkit/i.test(u)){st(function(){var dr=document.readyState;
if(dr=="loaded"||dr=="complete"){i()}else{st(arguments.callee,10);}},10);}
else if((/mozilla/i.test(u)&&!/(compati)/.test(u)) || (/opera/i.test(u))){
document.addEventListener("DOMContentLoaded",i,false); } else if(e){     (
function(){var t=document.createElement('doc:rdy');try{t.doScroll('left');
i();t=null;}catch(e){st(arguments.callee,0);}})();}else{window.onload=i;}})(capslock.init);